import "./CategoryCard.css";

const CategoryCard = ({ category }) => {
  const { name, description, image, link } = category;

  return (
    <a href={link} className="category-card">
      <div className="category-card-image-wrap">
        <img src={image} alt={name} className="category-card-image" />
        <div className="category-card-overlay" />
      </div>

      <div className="category-card-content">
        <h3 className="category-card-name">{name}</h3>
        <p className="category-card-description">{description}</p>
        <span className="category-card-cta">Explore Collection →</span>
      </div>
    </a>
  );
};

export default CategoryCard;
