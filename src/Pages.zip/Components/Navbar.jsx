import './Navbar.css';
import { Link, useNavigate } from "react-router-dom";

function Navbar() {
   const navigate = useNavigate();

  const handleLogout = () => {
    navigate("/");
  };

  return (
    <nav className="navbar">
      <strong>My Cart</strong>
      <div>
        <Link to="/home">Home</Link>
        <Link to="/about">About</Link>
        <Link to="/services">Services</Link>
        <Link to="/contact">Contact</Link>
        <button onClick={handleLogout}>Logout</button>
      </div>
    </nav>
  );

 
}

export default Navbar;